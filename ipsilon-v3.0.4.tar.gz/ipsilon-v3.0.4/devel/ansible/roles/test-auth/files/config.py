SECRET_KEY = "ohsosecret"
OIDC_CLIENT_SECRETS = "/home/vagrant/test-auth.client_secrets.json"
OIDC_SCOPES = [
    "openid",
    "email",
    "profile",
]
OPENID_ENDPOINT = "https://ipsilon.test/idp/openid/"
APPLICATION_ROOT = "/test-auth/"
