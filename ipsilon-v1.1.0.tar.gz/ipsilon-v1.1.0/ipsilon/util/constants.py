# Copyright (C) 2015 Ipsilon project Contributors, for license see COPYING

SOAP_MEDIA_TYPE = 'application/soap+xml'
XML_MEDIA_TYPE = 'text/xml'
