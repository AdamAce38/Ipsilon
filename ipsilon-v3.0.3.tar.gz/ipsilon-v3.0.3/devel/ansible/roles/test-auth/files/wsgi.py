import os
os.environ["TESTAUTH_SETTINGS"] = "/home/vagrant/test-auth.config.py"
os.environ["FLASK_DEBUG"] = "1"
from test_auth import application
